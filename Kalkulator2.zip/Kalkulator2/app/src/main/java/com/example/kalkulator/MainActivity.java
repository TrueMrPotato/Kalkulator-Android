package com.example.kalkulator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;


public class MainActivity extends AppCompatActivity {

    EditText number;

    Button button0;
    Button button1;
    Button button2;
    Button button3;
    Button button4;
    Button button5;
    Button button6;
    Button button7;
    Button button8;
    Button button9;
    Button plus;
    Button minus;
    Button razy;
    Button podzielic;
    Button rowna;
    Button reset;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        number = findViewById((R.id.editTextNumber));
        button0 = findViewById(R.id.button0);
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);
        button5 = findViewById(R.id.button5);
        button6 = findViewById(R.id.button6);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        button9 = findViewById(R.id.button9);
        plus = findViewById(R.id.buttonPlus);
        minus = findViewById(R.id.buttonMinus);
        razy = findViewById(R.id.buttonRazy);
        podzielic = findViewById(R.id.buttonPodzielic);
        rowna = findViewById(R.id.buttonWynik);
        reset = findViewById(R.id.buttonReset);


        button0.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String temp = number.getText().toString();
                        temp = temp + "0";
                        number.setText(temp);
                    }
                }
        );
        button1.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String temp = number.getText().toString();
                        temp = temp + "1";
                        number.setText(temp);
                    }
                }
        );
        button2.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String temp = number.getText().toString();
                        temp = temp + "2";
                        number.setText(temp);
                    }
                }
        );
        button3.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String temp = number.getText().toString();
                        temp = temp + "3";
                        number.setText(temp);
                    }
                }
        );
        button4.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String temp = number.getText().toString();
                        temp = temp + "4";
                        number.setText(temp);
                    }
                }
        );
        button5.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String temp = number.getText().toString();
                        temp = temp + "5";
                        number.setText(temp);
                    }
                }
        );
        button6.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String temp = number.getText().toString();
                        temp = temp + "6";
                        number.setText(temp);
                    }
                }
        );
        button7.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String temp = number.getText().toString();
                        temp = temp + "7";
                        number.setText(temp);
                    }
                }
        );
        button8.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String temp = number.getText().toString();
                        temp = temp + "8";
                        number.setText(temp);
                    }
                }
        );
        button9.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String temp = number.getText().toString();
                        temp = temp + "9";
                        number.setText(temp);
                    }
                }
        );

        plus.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String text = number.getText().toString();
                        text = text + "+";
                        number.setText(text);
                    }
                }
        );
        minus.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String text = number.getText().toString();
                        text = text + "-";
                        number.setText(text);
                    }
                }
        );
        razy.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String text = number.getText().toString();
                        text = text + "*";
                        number.setText(text);
                    }
                }
        );
        podzielic.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String text = number.getText().toString();
                        text = text + "÷";
                        number.setText(text);
                    }
                }
        );



        rowna.setOnClickListener(
                v -> {
                    String dzialanie = number.getText().toString();
                    double result;

                    try{
                        Expression expression = new ExpressionBuilder(dzialanie).build();
                        result = expression.evaluate();

                    } catch (Exception exception){
                        Toast.makeText(this, "Nieprawidłowe Działanie", Toast.LENGTH_LONG).show();
                        return;
                    }
                    number.setText(String.valueOf(result));

                }
        );
        reset.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String text = number.getText().toString();
                        text = "";
                        number.setText(text);
                    }
                }
        );
    }
}